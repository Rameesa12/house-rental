"""homerentalapp URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login),
    path('login_post',views.login_post),
    path('changepass',views.changepass),
    path('change_password_post',views.change_password_post),
    path('viewcustomers',views.viewcustomers),
    path('viewhouseowners',views.viewhouseowners),
    path('approve_house_owners/<id>',views.approve_house_owners),
    path('reject_house_owners/<id>',views.reject_house_owners),
    path('viewroomsanddetails/<id>',views.viewroomsanddetails),
    path('view_rating/<id>',views.view_rating),
    path('approved_owners',views.approved_owners),
    path('admin_home',views.admin_home),
    path('logout',views.logout),
    path('houseowner_register',views.houseowner_register),
    path('houseowner_register_post',views.houseowner_register_post),
    path('customer_register',views.customer_register),
    path('customer_register_post',views.customer_register_post),
]
